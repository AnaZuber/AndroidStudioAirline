package com.example.airline.ui.login;


import android.os.Bundle;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;


import com.example.airline.R;
import com.example.airline.ui.home.HomeViewModel;

public class LoginActivity extends Fragment {

    private Button login;
    private EditText username;
    private EditText password;
    private LoginViewModel loginViewModel;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        loginViewModel =
                new ViewModelProvider(this).get(LoginViewModel.class);
        View root = inflater.inflate(R.layout.activity_login, container, false);
        login = (Button) root.findViewById(R.id.login);

        login.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                username = (EditText) (root.findViewById(R.id.username));
                password = (EditText) (root.findViewById(R.id.password));
                loginViewModel.setUsername(username.getText().toString());
                loginViewModel.setPassword(password.getText().toString());
                Log.d("idemo", loginViewModel.getUsername());
                AuthService a = new AuthService();
                a.doInBackground("https://bjelicaluka.live:4000/login","username:" + username + "password:" + password);
            }
        });




        return root;
    }
}



